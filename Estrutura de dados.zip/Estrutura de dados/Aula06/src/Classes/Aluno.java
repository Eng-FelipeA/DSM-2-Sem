/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author Alunos
 */
public abstract class Aluno extends Pessoa{
    protected String nota;
    
    public Aluno(String nome, String genero, int idade, String nota){
        super(nome, genero, idade);
        this.nota = nota;
    }
    
    public abstract String exibirNota();
    
    public abstract String setNota();
    
}
