/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author Alunos
 */
public final class Fundamental extends Aluno{
    
    public Fundamental(String nome, String genero, int idade, String nota){
    super(nome, genero, idade, nota);

    }
       public String getNota() {
         int notaf= Integer.parseInt(super.nota);
            if(notaf>10) return "Nota inválida";
            else if(notaf==10) return "A";
            else if(notaf >= 8) return "B";
            else if(notaf >= 6) return "C";
            else if(notaf >= 4) return "D";
            else if(notaf >= 3) return "E";
            else return "F";

   }
    public void setNota(String nota){
        

    }
    
    public void exibirNota(String nota){

        
    }
    
}
