package Classes;

import java.util.*;

public class Controle {
    
    //atributos
    
    private java.util.List<Object> listaProfessores;
    private java.util.List<Object> listaAdministrativo;
    private java.util.List<Object> listaFundamental;
    
    
    public Controle(){
        listaProfessores = new ArrayList<Professor>();
        listaAdministrativo = new ArrayList<Administrativo>();
        listaFundamental = new ArrayList<Fundamental>();
    }
    
    //método para criar um novo professor e adiciona-lo a listaProfessores
    public void addProfessor(String nome, EnumGenero genero, int idade){
        //criar o professor
        listaProfessores.add(new Professor(nome, genero, idade));
    }
    //método para criar um novo func. administrativo e adiciona-lo a listaAdministrativo
    public void addAdministrativo(String nome, Enum genero, int idade){
        //criar administrativo
        listaAdministrativo.add(new Administrativo(nome, genero, idade));
    }
    //método para criar um novo aluno fundamental
    public void addFundamental(String nome, Enum genero, int idade){
        //criar fundamental
        listaFundamental.add(new Fundamental, genero, idade);
    }
    
}
