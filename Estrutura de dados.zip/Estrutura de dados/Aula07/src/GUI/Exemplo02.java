package GUI;

import javax.swing.JFrame;

public class Exemplo02 {
    private JFrame janela;
    //Construtor
    public Exemplo02(){
        janela = new JFrame("Primeira Janela");
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        janela.setSize(400,300);
        janela.setVisible(true);
        
    }
    
    public static void main(String[] args){
        new Exemplo02();
    }
    
}
