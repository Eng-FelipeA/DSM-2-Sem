package GUI;

import javax.swing.JFrame;

public class Exemplo01 {
    private JFrame janela;
    public Exemplo01(){
        janela = new JFrame("Primeira Janela");
        janela.setSize(400,300);
        janela.setVisible(true);//Define q a janela estará visivel
        
    }
    
    public static void main(String[] args){
        Exemplo01 p = new Exemplo01();//instancia a tela
    }
}
