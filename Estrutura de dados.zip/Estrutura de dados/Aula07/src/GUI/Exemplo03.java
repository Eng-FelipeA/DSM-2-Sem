package GUI;

import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Exemplo03 {
    private JFrame janela;
    
    public Exemplo03(){
        janela = new JFrame("Janela com componentes");
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //atribui o container de janela a variavel c
        Container c = janela.getContentPane();
        JLabel rotulo = new JLabel("Elemento JLabel");
        JButton botao = new JButton("Botão Simples");
        c.setLayout(new FlowLayout());//define o estilo de layout
        c.add(rotulo);
        c.add(botao);
        
        
        janela.setSize(400,300);
        janela.setVisible(true);
    }
    
    public static void main(String[] args){
        new Exemplo03();
    }
}
