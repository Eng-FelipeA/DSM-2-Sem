package GUI;

public class Exemplo04 {
    private JFrame janela;
    
    public Exemplo04(){
        janela = new JFrame("Janela com componentes")
    }
    
}
