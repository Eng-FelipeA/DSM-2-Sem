package Arvores;
public class Arvore {

    public static void main(String[] args) {
        // TODO code application logic here
        

            ArvoreBinaria arvore = new ArvoreBinaria(100);
            
            arvore.adicionarOrdenado(30);
            arvore.adicionarOrdenado(150);
            arvore.adicionarOrdenado(20);
            arvore.adicionarOrdenado(35);
            
            arvore.busca(35);
        }
    }
    

