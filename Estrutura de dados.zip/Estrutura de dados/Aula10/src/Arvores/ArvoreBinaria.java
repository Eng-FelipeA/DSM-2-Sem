package Arvores;
public class ArvoreBinaria {
    //atributos
    NoBinario raiz;
    public ArvoreBinaria(Integer info){
        raiz=new NoBinario(info, null, null);
        
    }
    //Metodo para adicionar de forma ordenada valores inteiros na arvore
    public void adicionarOrdenado(Integer valor){
        //se valor > info adicionar no nó da direira, 
        //se o valor for <= infor adicionar a esquerda
        if(valor > raiz.getInfo()) //info da raiz
        {
            if (raiz.getDireita() == null) //Adiciona valor nessa posição
            {
                raiz.setDireita(new NoBinario(valor, null, null));
            }
            else
                adicionarFilhos(raiz.getDireita(), valor);
        }
        else // adiciona na esquerda
        {
            //se o nó filho da raiz não for nula, passamos o no filho como referencia e verifica o no q está nessa posição
            if(raiz.getEsquerda() == null) // adiciona valor nessa posição
            {
                raiz.setEsquerda(new NoBinario(valor, null, null));
            }
            else
                adicionarFilhos(raiz.getEsquerda(), valor);
        }
        {
            
        }
        

            
    }
        private void adicionarFilhos(NoBinario no, Integer valor){
                    //se valor > info adicionar no nó da direira, 
        //se o valor for <= infor adicionar a esquerda
        if(valor > no.getInfo()) //info da raiz
        {
            if (no.getDireita() == null) //Adiciona valor nessa posição
            {
                no.setDireita(new NoBinario(valor, null, null));
            }
            else
                adicionarFilhos(no.getDireita(), valor);
        }
        else // adiciona na esquerda
        {
            //se o nó filho da raiz não for nula, passamos o no filho como referencia e verifica o no q está nessa posição
             if(no.getEsquerda() == null) // adiciona valor nessa posição
            {
                no.setEsquerda(new NoBinario(valor, null, null));
            }
            else{
                adicionarFilhos(no.getEsquerda(), valor);
            }
            
        }
        {
           
        }
    }
        
        
    public void busca(Integer valor){
        buscaFilhos(valor, raiz, 0);
        
    }   
    private boolean buscaFilhos(Integer valor, NoBinario no, int profundidade){
        if(no == null){
            System.out.println("Não encontrado!" + profundidade);
            return false;
        }
        else if(valor == no.getInfo()){
            System.out.println("Encontrado: " + profundidade);
            return true;
        }
        else{
            if(buscaFilhos(valor, no.getDireita(), profundidade+1) == false){
                buscaFilhos(valor, no.getEsquerda(), profundidade+1);
            }
        }
        return false;
    } 
}
