package Arvores;
public class NoBinario {
    //Classe Nó para àrvore binária
    //Atributos
    private Integer info;
    private NoBinario esquerda, direita;
 
    //Construtor
public NoBinario(Integer info, NoBinario esquerda, NoBinario direira){
    this.info=info;
    this.esquerda=esquerda;
    this.direita=direita;
}
    //Métodos geters e seters
    public Integer getInfo() {
        return info;
    }

    public NoBinario getEsquerda() {
        return esquerda;
    }

    public NoBinario getDireita() {
        return direita;
    }

    public void setInfo(Integer info) {
        this.info = info;
    }

    public void setEsquerda(NoBinario esquerda) {
        this.esquerda = esquerda;
    }

    public void setDireita(NoBinario direita) {
        this.direita = direita;
    }

}
