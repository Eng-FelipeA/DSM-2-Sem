principal;

import static principal.Fatorial.calcularFatorialComInteracao;
import static principal.Fatorial.calcularFatorialRecursivo;

public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numero = 5;
        long fatorialRecursivo = calcularFatorialRecursivo(numero);
        System.out.println("Fatorial (Recursivo) de " + numero + " é " + fatorialRecursivo);
                // Opção 2: Calcular o fatorial com interação do usuário
        calcularFatorialComInteracao();
    }
