package ListaLigada;

public class ListaLigada {
    private No primeiroNo;
    private No ultimoNo;
    private int qtdNo;
    
    public ListaLigada(){
        primeiroNo = null;
        ultimoNo = null;
        qtdNo = 0;
    }
    
    public void adicionar(Object info){
        No novoNo;
        if(primeiroNo == null){
            //iniciando a lista
            novoNo = new No(info, null);
        primeiroNo = ultimoNo = novoNo;
        qtdNo++;
        }
        else{
            //adiciona o No no final da lista
            novoNo = new No(info, null);
            ultimoNo.setProximo(novoNo);
            ultimoNo = novoNo;
            qtdNo++;
            
        }
    }
        
    public void adicionar(Object info, int indice){
        //adiciona um novo no na posição definida pelo indice.
        //Se o indice for maior q qtdNo, adiciona o nó na ultima posição
        //Se o indice for menor q 0, não faz nada
        No novoNo;
        
        if(indice >= 0){
            //adiciona o no na primeira posição da lista
            if(indice >= qtdNo){
                adicionar(info);
            }
        }
        else if(indice == 0){
            //para adicionar o Nó na primeira posição, o novo Nó precisa apontar para o primeiro nó e a ref. para o primeiro nó precisa ser atualizada
            novoNo = new No(info, primeiroNo);
            primeiroNo = novoNo;
            qtdNo++;
        }
        else{
            //todos os casos onde será adicionado no meio da lista
            //aux recebe referencia para o nó de indice-1
            No aux = percorrerLista(indice-1);
            //novoNo é criado com a referencia para o proximo Nó, como aux=>proximoNo
            novoNo = new No(info, aux.getProximo());
            //aux atualiza a referencia para o proximo nó, atribuindo o novo nó
            aux.setProximo(novoNo);
            qtdNo++;
        }
    }
    public void remover(int indice){
        No aux;
        if(indice==0){
            //remove da primeira posição da lista
            primeiroNo = primeiroNo.getProximo();
            qtdNo--;
        }
        else if(indice == qtdNo-1){
            //remove da ultima posição da lista
            aux = percorrerLista(indice-1);
            aux.setProximo(null);
            ultimoNo = aux;
            qtdNo--;
            
                    
                    
        }
        else{
            //remove de qualquer outra posição da lista
        }
        aux = percorrerLista(indice-1);
        aux.setProximo(aux.getProximo().getProximo());
        qtdNo--;
        
    }
    public String exibirLista(){
        //Percorre toda lista retornando uma String com o info de todos os Nós
        String retorno = "Lista: ";
        No aux = primeiroNo;
        while(aux.getProximo()!=null){
            //concatena as informações dos nós
            retorno += aux.getInfo()+" ";
            //percorre a lista
            aux=aux.getProximo();
        }
        return retorno;
    }
        
    
    public String getLista(int indice){
        return percorrerLista(indice).getInfo().toString();
    }

    private No percorrerLista(int indice){
        if(indice >= 0 && indice < qtdNo){
            No aux = primeiroNo;
            
            for(int i=0; i < indice; i++){
                aux = aux.getProximo();
            }
            return aux;
            
        }
        else{
            return null;
        }
    }
    
}
