package Pilhas;

public class PilhaArray {
    private Object[] pilha;
    private int topo=0;
    public PilhaArray(int tamanho){
        pilha = new Object[tamanho];
        
    }
    public boolean empilhar(Object item){
        this.pilha = new Object[10];
    }
    
    
}
