/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Filas;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alunos
 */
public class FilaPrioridade {
        private List<Object> filaP;
    
    public FilaPrioridade(){
        //variável fila está sendo instanciada...
        filaP = new ArrayList<Object>();
    }
    
    public void adicionar(Object item){
        //os itens serão adicionados em orderm crescente
        //valores menores no inicio e maiores no final
        boolean foiAdicionado=false;
        if(filaP.isEmpty())
            filaP.add(item);
        else{
            for (int i=0; i < filaP.size(); i++){
                if (Integer.parseInt(filaP.get(i).toString()) > Integer.parseInt(item.toString())){
                    filaP.add(i, item); break;
                }
            }
            if (foiAdicionado==false){
                filaP.add(item);
            }
        }
    }
    public Object remover(){
        if(!filaP.isEmpty())
            return filaP.remove(0);
        else
            return "Fila vazia.";
    }
    public Object exibirInicio(){
        return filaP.get(0);
    }
    public int tamanho(){
        return filaP.size();
    }
    
}
