/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estruturade.dados;

import Filas.Fila;
import Filas.FilaPrioridade;
import ListaLigada.*;
import ListaLigada.No;
import Pilhas.Pilha;

/**
 *
 * @author Alunos
 */
public class EstruturaDeDados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /**
        PilhaArray pilha1[] = new PilhaArray[10];
        pilha1.empilhar[0] = 1;

        System.out.println(pilha1);
        
       
        FilaPrioridade filaNumero=new FilaPrioridade();
        
        filaNumero.adicionar(1);
        filaNumero.adicionar(2);
        filaNumero.adicionar(3);
        filaNumero.adicionar(4);
        
        for(int i=filaNumero.tamanho();i>0;i--){
            System.out.println("Remover: " + filaNumero.remover().toString());
        }**/
       ListaLigada lista = new ListaLigada();
        
        lista.adicionar(1);
        lista.adicionar(2);
        lista.adicionar(3);
        System.out.println(lista.exibirLista());
        
        lista.adicionar("x",2);
        System.out.println(lista.exibirLista());
        lista.remover(1);
        System.out.println(lista.exibirLista());
        
        
        
    }
    
}
