package Classes;

import java.util.*;

public class Controle {
    
    //atributos
    
    private java.util.List<Object> listaProfessores;
    
    public Controle(){
        listaProfessores = new ArrayList<Professor>();
    }
    
    //método para criar um novo professor e adiciona-lo a listaProfessores
    public void addProfessor(String nome, EnumGenero genero, int idade){
        //criar o professor
        listaProfessores.add(new Professor(nome, genero, idade));
    }
    
}
