
package hanoi;

public class TorreDeHanoi {
        public static void resolverTorreHanoi(int numeroDiscos, String origem, String auxiliar, String destino) {
        if (numeroDiscos == 1) {
            System.out.println("Disco 1 | " + origem + " => " + destino);
        } else {
            resolverTorreHanoi(numeroDiscos - 1, origem, destino, auxiliar);
            System.out.println("Disco " + numeroDiscos + " | " + origem + " => " + destino);
            resolverTorreHanoi(numeroDiscos - 1, auxiliar, origem, destino);
        }
    }
    
}
