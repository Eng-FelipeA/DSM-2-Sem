
package hanoi;

import static hanoi.TorreDeHanoi.resolverTorreHanoi;
import java.util.Scanner;

public class Hanoi {

    public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o número de discos na Torre de Hanoi: ");
        int numeroDiscos = scanner.nextInt();

        System.out.println("========== Inicio =========");
        resolverTorreHanoi(numeroDiscos, "origem", "auxiliar", "destino");
        System.out.println("============ Fim ==========");

        scanner.close();
    }
    }
    

