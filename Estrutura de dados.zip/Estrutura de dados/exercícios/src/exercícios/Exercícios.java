package exercícios;
public class Exercícios {

    public static void main(String[] args) {
    ListaLigada lista = new ListaLigada();
    lista.adicionar("João");
    lista.adicionar("Maria");
    lista.adicionar("Pedro");

    int indice = lista.getLista("João");
    if (indice != -1) {
        System.out.println("O objeto foi encontrado no índice: " + indice);
    } else {
        System.out.println("O objeto não foi encontrado na lista.");
    }
    boolean removido = lista.remover("Banana");
    if (removido) {
        System.out.println("Objeto removido com sucesso.");
    } else {
        System.out.println("O objeto não foi encontrado na lista.");
    }
    ListaLigada lista1 = new ListaLigada();
    lista1.adicionar("Felipe");
    lista1.adicionar("Camila");
    ListaLigada lista2 = new ListaLigada();
    lista2.adicionar("Lucca");
    lista2.adicionar("João");

    lista1.concatenar(lista2);

    System.out.println(lista1.exibirLista());
    
    ListaLigada copia = lista.copiar();

    System.out.println("Lista Original: " + lista.exibirLista());
    System.out.println("Cópia da Lista: " + copia.exibirLista());


        
        
    }
    
}
