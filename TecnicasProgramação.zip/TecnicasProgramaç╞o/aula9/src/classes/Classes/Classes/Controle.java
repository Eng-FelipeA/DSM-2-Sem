
package Classes;


import java.util.*;

public class Controle {
    
   
     private List<Object> listaPessoa;
    
    
    public Controle(){       
      listaPessoa= new ArrayList<Object>();
    }
    
    public void addPessoa(String nome, int idade, EnumGenero genero){
       listaPessoa.add(new Professor(nome, genero, idade));
    }
    public boolean removerPessoa(int indice){
        if(indice>=0 && indice< listaPessoa.size()){
            listaPessoa.remove(indice);
            return true;
        }
        else
            return false;
    
    }
    public java.util.List<Object> getListaPessoa() {
        return listaPessoa;
    }
    

}
