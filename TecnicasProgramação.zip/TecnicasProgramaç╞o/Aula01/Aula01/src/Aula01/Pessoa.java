/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aula01;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alunos
 */
public class Pessoa {
    
    String nome;
    int idade;
    Pessoa mae, pai, irmaos;
    List<Pessoa> filhos = new ArrayList<>();

    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
    
    public String nomeFilhos(){
        String mensagem="Meus filhos sao ";

        for(int i=0;i<filhos.size();i++)
        {
            mensagem +=filhos.get(i).nome + ", ";
        }
        return mensagem;
    
    }
     
    
}
