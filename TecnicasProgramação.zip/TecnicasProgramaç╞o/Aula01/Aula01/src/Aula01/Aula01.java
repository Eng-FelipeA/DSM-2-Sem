/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aula01;

/**
 *
 * @author Alunos
 */
public class Aula01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String msg, msg2;
        Pessoa felipe = new Pessoa("Felipe", 34);
        Pessoa rosa = new Pessoa("Rosa", 55);
        Pessoa sandro = new Pessoa("Sandro", 52);
        
        //Filhos
        Pessoa lucca, pedro;
        lucca = new Pessoa("Lucca", 1);
        pedro = new Pessoa("Pedro", 15);
        
        /*felipe.nome="Felipe";
        rosa.nome="Rosa"
        felipe.idade=34;*/
        felipe.mae=rosa;
        felipe.pai=sandro;
        felipe.filhos.add(lucca);
        felipe.filhos.add(pedro);
        
        msg=felipe.mae.nome + " e mae do " + felipe.nome + " e " + felipe.pai.nome + " e o pai. ";
        msg2="Felipe tem " + felipe.filhos.size() + " filhos." + "\n" + felipe.nomeFilhos();
        System.out.println(msg + "\n" + msg2);
    }
    
}

