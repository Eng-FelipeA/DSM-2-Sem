/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alunos
 */
public class Pessoa {
    //Variáveis

   private String nome;
   private int idade;
   private Pessoa mae;
   private Pessoa pai;
   List<Pessoa> irmao;
   List<Pessoa> filhos;

   public Pessoa(String nome) {
      this.irmao = new ArrayList();
      this.filhos = new ArrayList();
      this.nome = nome;
   }

   public Pessoa(String nome, int idade) {
      this(nome);
      this.idade = idade;
   }

   public Pessoa(String nome, int idade, Pessoa mae) {
      this(nome, idade);
      this.mae = mae;
      this.setFilhos();
      this.addIrmaos();
   }

   public void setNome(String nome) {
      this.nome = nome;
   }

   public void setIdade(int idade) {
      this.idade = idade;
   }

   public void setMae(Pessoa mae) {
      this.mae = mae;
   }

   public void setFilhos() {
      this.mae.filhos.add(this);
   }

   private void setIrmaos() {
      if (this.mae != null) {
         List<Pessoa> irmaosTemp = new ArrayList();

         for(int i = 0; i < this.mae.filhos.size(); ++i) {
            Pessoa irmaoPotencial = (Pessoa)this.mae.filhos.get(i);
            if (irmaoPotencial != this) {
               irmaosTemp.add(irmaoPotencial);
            }
         }

         this.irmao = irmaosTemp;
      }

   }

   private void addIrmaos() {
      if (this.mae != null) {
         for(int i = 0; i < this.mae.filhos.size(); ++i) {
            ((Pessoa)this.mae.filhos.get(i)).setIrmaos();
         }
      }

   }

   public String getNome() {
      return this.nome;
   }

   public int getIdade() {
      return this.idade;
   }

   public Pessoa getMae() {
      return this.mae;
   }

   public int qtdIrmaos() {
      return this.irmao.size();
   }

   public int qtdFilhos() {
      return this.filhos.size();
   }

   public String nomeIrmaos() {
      String mensagem = "Meus irmãos são: ";

      for(int i = 0; i < this.irmao.size(); ++i) {
         if (i < this.irmao.size() - 1) {
            mensagem = mensagem + ((Pessoa)this.irmao.get(i)).nome + ", ";
         } else {
            mensagem = mensagem + ((Pessoa)this.irmao.get(i)).nome + ".";
         }
      }

      return mensagem;
   }

   public String nomeFilhos() {
      String mensagem = "Os filhos da mãe são: ";

      for(int i = 0; i < this.filhos.size(); ++i) {
         if (i < this.filhos.size() - 1) {
            mensagem = mensagem + ((Pessoa)this.filhos.get(i)).nome + ", ";
         } else {
            mensagem = mensagem + ((Pessoa)this.filhos.get(i)).nome + ".";
         }
      }

      return mensagem;
   }
   
}
