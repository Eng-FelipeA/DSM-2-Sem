package aula04;

import java.util.ArrayList;
import java.util.List;

public class Pessoa {
     public String nome;
    public String dataNascimento;
    
    //private Pessoas pai;
    //private Pessoas mae;        
    public Pessoa pais[]=new Pessoa[2];
    /* As variáveis pai e mãe foram substituidas por um vetor do tipo Pessoa que irá armazenar na posição [0] o pai e na posição [1] a mãe
    pais[0] ==> MAE
    pais[1] ==> PAI*/
    public List<Pessoa> filhos= new ArrayList<>();
    public List<Pessoa> irmaos=new ArrayList<>();
    public List<Pessoa> primos=new ArrayList<>();
    
    public Pessoa(){}
    //****  Construtores ********
    public Pessoa(String nome) {
        this.nome = nome;
    }    
    public Pessoa(String nome, Pessoa mae){
        this(nome);
        AddMaternidade(mae);
    }
    public Pessoa(String nome, Pessoa mae, Pessoa pai){
        this(nome,mae);
        AddPaternidade(pai);
    }
    public Pessoa(String nome, Pessoa mae, Pessoa pai, String nascimento) {
        this(nome,mae,pai) ;        
        this.dataNascimento = nascimento; 
    }
    //**************************************
    
    //***** Métodos Publicos *****
    public void AddPaternidade(Pessoa pai)
    {
        this.pais[1]=pai;
        pai.addFilho(this);
    }
    public void AddMaternidade(Pessoa mae)
    {
        this.pais[0]=mae;
        mae.addFilho(this);
    }
     public void addFilho(Pessoa filho){
                    
        for(int i=0; i<filhos.size();i++){            
            filho.addIrmao(filhos.get(i));
            filhos.get(i).addIrmao(filho);
        }
        addLista(filhos, filho);
    }
    private void addIrmao(Pessoa irmao){   
        
        addLista(irmaos , irmao);
    }
    //************************************
    
    //***** Métodos internos privados ****
    private void addLista(List<Pessoa> lista, Pessoa p){
        for(int i=0; i<lista.size();i++){
            //Verificar se o item Pessoa já foi adicionado antes de incluir na lista
            if (lista.get(i).equals(p)) return;
        }
        lista.add(p);        
    }    
    ///**********************************
    
    // *** Metodos Getters e Setters ****
    public String getNomePai() {
        return pais[1].nome;
    }
    
    public String getNomeMae() {
        return pais[0].nome;
    }      
    
    public int getQtdFilhos(){
        return filhos.size();
    }
    public int getQtdIrmaos(){
        return irmaos.size();
    }
    
     public String listaIrmaos(){
        String listaIrmaos="";
        for (int i=0;i<irmaos.size();i++){
            listaIrmaos+= irmaos.get(i).nome;
            if (i<irmaos.size()-1){
                listaIrmaos+=", ";}
        }
        return listaIrmaos;
    }
    public String listaFilhos(){
        String listaFilhos="";
        for (int i=0;i<filhos.size();i++){
            listaFilhos+= filhos.get(i).nome;
            if (i<filhos.size()-1){
                listaFilhos+=", ";
            }
        }        
        return listaFilhos;
    }
    
    public String listaSobrinhos(){
        String listaSobrinhos="";
        String resp;
        for (int i=0;i<irmaos.size();i++){
            resp= irmaos.get(i).listaFilhos();
            if (resp.length() >0){ 
                listaSobrinhos+=resp;
                if (i<irmaos.size()-1){
                listaSobrinhos+=", ";}
            } 
        }
        return listaSobrinhos;
    }
    public String listaTios(){
        String listaTios="";
        String resp;
        for (Pessoa pai : pais) {
            for (int i = 0; i < pai.getQtdIrmaos(); i++) {
                resp = pai.irmaos.get(i).nome;
                if (resp.length() >0) { 
                    listaTios+=resp;
                    if (i < pai.getQtdIrmaos() - 1) {
                        listaTios+=", ";
                    } 
                }
            }
        }
        return listaTios;
    }
     /*public String listaTios(){
        String listaTios="";
        String resp;
        for(int j=0; j<pais.length;j++){
            for (int i=0;i<pais[j].getQtdIrmaos() ;i++){
                resp= pais[j].irmaos.get(i).nome;
                if (resp.length() >0){ 
                    listaTios+=resp;
                    if (i<pais[j].getQtdIrmaos()-1){
                    listaTios+=", ";}
                } 
            }
        }
        return listaTios;
    }*/
   
    public String listaAvos(){
        String listaAvos="";
        String resp;
        for (int i=0;i<pais.length;i++){
            for (int j=0;j<pais[i].pais.length;j++){
                if(pais[i].pais[j] != null){
                    resp=pais[i].pais[j].nome;
                    if (resp.length() >0){
                        if (listaAvos.length()>0){
                        listaAvos+=", "+resp;}
                        else
                            listaAvos+=resp;
                    }
                }
            }
        }
        return listaAvos;
    }
    
}
