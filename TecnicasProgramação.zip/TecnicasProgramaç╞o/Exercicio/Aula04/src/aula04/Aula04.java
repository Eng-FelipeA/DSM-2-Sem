package aula04;
public class Aula04 {

    public static void main(String[] args) {
      Pessoa arvore[]=new Pessoa[20];      
        //1ºGeração
        arvore[0]= new Pessoa("Maria I");
        arvore[1]=new Pessoa("Pedro III");
        //2ºGeração
        arvore[2]=new Pessoa("Dom Jose", arvore[0], arvore[1], "01/01/1761");
        arvore[3]=new Pessoa("Joao VI", arvore[0], arvore[1], "01/01/1767");
        arvore[4]=new Pessoa("Mariana Vitoria", arvore[0], arvore[1], "01/01/1768");
        //Esposas
        arvore[5] = new Pessoa("Carlota Joaquina");
        arvore[6]= new Pessoa("Maria Leopoldina");
        arvore[7]= new Pessoa("Teresa Cristina");
        //3ºGeração
        arvore[8]=new Pessoa("Dom Pedro I", arvore[5], arvore[3], "01/01/1798");
        arvore[9]=new Pessoa("Miguel I", arvore[5], arvore[3], "01/01/1801");
        arvore[10]=new Pessoa("Isabel Maria", arvore[5], arvore[3], "01/01/1801");
        //4ºGeração
        arvore[11]=new Pessoa("Dom Pedro II", arvore[6], arvore[8], "01/01/1825");        
         //5ºGeração
        arvore[12]=new Pessoa("Princesa Isabel", arvore[7], arvore[11], "01/01/1846");
        //Esposo
        arvore[13]=new Pessoa("Conde d'Eu");        
        //6º Geração
        arvore[14]=new Pessoa("Pedro de Alcantara", arvore[12], arvore[13], "01/01/1875");
         
        // Imprime o resultado no console
        int i=0;
        System.out.println(arvore[i].nome +" tem "+ arvore[i].getQtdFilhos()+" filhos ("+ arvore[i].listaFilhos()+ ") e " 
        + arvore[i].getQtdIrmaos() + " irmaos (" + arvore[i].listaIrmaos()+ ") \n ===========");
        i=2;
        System.out.println(arvore[i].nome +" tem "+ arvore[i].getQtdFilhos()+" filhos ("+ arvore[i].listaFilhos()+ ") e " 
        + arvore[i].getQtdIrmaos() + " irmaos (" + arvore[i].listaIrmaos()+ ") \n ===========");
        i=3;
        System.out.println(arvore[i].nome +" tem "+ arvore[i].getQtdFilhos()+" filhos ("+ arvore[i].listaFilhos()+ ") e " 
        + arvore[i].getQtdIrmaos() + " irmaos (" + arvore[i].listaIrmaos()+ ") \n ===========");
        i=4;
        System.out.println(arvore[i].nome +" tem "+ arvore[i].getQtdFilhos()+" filhos ("+ arvore[i].listaFilhos()+ ") e " 
        + arvore[i].getQtdIrmaos() + " irmaos (" + arvore[i].listaIrmaos()+ ") \n ===========");
        
        System.out.println(arvore[2].nome+"==> Meus sobrinhos sao: \t"+arvore[2].listaSobrinhos()+"\n ===========");
        System.out.println(arvore[11].nome +"==> Meus tios sao: \t"+arvore[11].listaTios() +"\n ===========");  
        System.out.println(arvore[14].nome+ "==> Meus avos sao: \t"+arvore[14].listaAvos()); 
        
       // Imprime os Ascendentes
        String resp= listaAscendentesPaternos(arvore[11],2);
        System.out.println(arvore[11].nome+": "+ resp);
        resp= listaAscendentesPaternos(arvore[11]);
        System.out.println(arvore[11].nome+": "+ resp);
    }
    
    public static String listaAscendentesPaternos(Pessoa p){
        
        if(p.pais[1] != null){
            return " => " + p.getNomePai()+listaAscendentesPaternos(p.pais[1]);
        }
        return "";
    }
    public static String listaAscendentesPaternos(Pessoa p,int iGeracao){
        
        if (iGeracao>0){
            if(p.pais[1] != null){
                return " => " + p.getNomePai()+listaAscendentesPaternos(p.pais[1],iGeracao-1);
            }
        }
        return "";
    }
    
    }

