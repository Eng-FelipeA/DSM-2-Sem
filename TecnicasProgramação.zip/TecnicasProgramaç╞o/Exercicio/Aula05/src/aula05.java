public class aula05 {
    public static void main(String[] args) {
        Pessoa felipe = new Pessoa("Felipe Afonso da Silva Vieira", "362795908-60", "(15) 996914747", "Av. Adolpho Massaglia, 800, Vossoroca, Votorantim/SP");
        Aluno lucca = new Aluno("Lucca de Araujo Vieira", 9830456, felipe, 10.0);
        System.out.println("Meu nome é " + felipe.getNome() + ", meu CPF é " + felipe.getCpf() + ", meu telefone é " + felipe.getTelefone() + " e meu endereço é " + felipe.getEndereco());
        System.out.println("Nome do aluno: " + lucca.getNome() + ", o responsável é o pai, " + lucca.getResponsavel() + " seu RA é " + lucca.getRa() + " e sua média final é " + lucca.getMediaFinal());
    }
    
}
