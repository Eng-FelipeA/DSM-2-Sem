/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alunos
 */
public class Aluno extends Pessoa{
    int ra;
    Pessoa responsavel;
    double mediaFinal;
    
    public Aluno(String nome){
        super(nome);
    }
    
    public Aluno(String nome, int ra) {
        super(nome);
        this.ra = ra;
    }
    public Aluno(String nome, int ra, Pessoa responsavel) {
        this(nome, ra);
        this.responsavel = responsavel;
    }
    public Aluno(String nome, int ra, Pessoa responsavel, double mediaFinal) {
        this(nome, ra, responsavel);
        this.mediaFinal = mediaFinal;
    }
    
    //setters
    
    public void setRa(int ra){
        this.ra = ra;
    }
    public void setResponsavel(Pessoa responsavel){
    this.responsavel = responsavel;
    }
    public void setMediaFnal(double mediaFinal){
    this.mediaFinal = mediaFinal;
    }
    
    //getters
    public int getRa(){
        return this.ra;
    }
    public Pessoa getResponsavel(){
        return this.responsavel;
    }
    public double getMediaFinal(){
        return this.mediaFinal;
    }
    @Override
        public String getNome(){
        return "Sr" + super.nome;
    }
}
