
public class Pessoa {
    String nome;
    private String cpf;
    private String telefone;
    private String endereco;
    
    
    //construtores
    public Pessoa(String nome){
        this.nome = nome;
    }
    public Pessoa(String nome, String cpf){
        this(nome);
        this.cpf = cpf;
    }
    public Pessoa(String nome, String cpf, String telefone){
        this(nome,cpf);
        this.telefone = telefone;
    }
    public Pessoa(String nome, String cpf, String telefone, String endereco){
        this(nome,cpf,telefone);
        this.endereco = endereco; 
    }
    //Setters
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setCpf(String cpf){
        this.cpf = cpf;
    }
    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    public void setEndereco(String endereco){
        this.endereco = endereco;
    }
    
    //Getters
    public String getNome(){
        return this.nome;
    }
    public String getCpf(){
        return this.cpf;
    }
    public String getTelefone(){
        return this.telefone;
    }
    public String getEndereco(){
        return this.endereco;
    }
        
}
