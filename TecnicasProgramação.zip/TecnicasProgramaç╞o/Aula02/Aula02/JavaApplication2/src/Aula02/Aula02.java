/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aula02;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alunos
 */
public class Aula02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //List<Pessoa> arvoreG = new ArrayList<>();
        Pessoa[] arvore = new Pessoa[10];
        //Avos
        arvore[0]=new Pessoa("Julio");
        arvore[1]=new Pessoa("Benedicta");
        //Pais
        arvore[2]=new Pessoa("Rosa", 55);
        arvore[3]=new Pessoa("Sandro", 52);
        //Eu
        arvore[4]=new Pessoa("Felipe", 34, arvore[2]);
        //Irmãos
        arvore[5]=new Pessoa("Jonathan", 32, arvore[2]);
        arvore[6]=new Pessoa("Jeniffer", 25, arvore[2]);
        arvore[7]=new Pessoa("Rebeca", 23, arvore[2]);
        arvore[8]=new Pessoa("Stefanny", 21, arvore[2]);
        
        System.out.println(arvore[4].getNome() + " => Mãe: " + arvore[4].getMae().getNome());
        System.out.println(arvore[4].nomeIrmaos());
    }
}
