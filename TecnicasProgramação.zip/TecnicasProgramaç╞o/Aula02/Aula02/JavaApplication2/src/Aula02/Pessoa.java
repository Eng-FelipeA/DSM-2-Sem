/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aula02;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alunos
 */
public class Pessoa {
    //Variáveis
    private String nome;
    private int idade;
    private Pessoa mae, pai;
    private List<Pessoa> filhos = new ArrayList<>();
    private List<Pessoa> irmaos = new ArrayList<>();
    
    //Construtor
    public Pessoa(String nome){
        this.nome = nome;
    }
    public Pessoa(String nome, int idade) {
        this(nome);
        this.idade = idade;
    }
    public Pessoa(String nome, int idade, Pessoa mae){
        this(nome,idade);
        this.mae = mae;
    }
    public Pessoa(String nome, int idade, Pessoa mae, Pessoa pai){
        this(nome,idade,mae);
        this.pai = pai;
    }
    //************************************************
    //Seters
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setIdade (int idade){
        this.idade = idade;
    }
    public void setMae (Pessoa mae){
        this.mae = mae;
    }
    public void setPai (Pessoa pai){
        this.pai = pai;
    }
    private void setIrmaos() {
    if (this.mae != null) {
      List<Pessoa> irmaosTemp = new ArrayList();

      for(int i = 0; i < this.mae.filhos.size(); ++i) {
         Pessoa irmaoPotencial = (Pessoa)this.mae.filhos.get(i);
         if (irmaoPotencial != this) {
            irmaosTemp.add(irmaoPotencial);
         }
      }

      this.irmaos = irmaosTemp;
     }

}
    //*********************************************
    private void loadIrmaos() {
    if (this.mae != null) {
      for(int i = 0; i < this.mae.filhos.size(); ++i) {
         ((Pessoa)this.mae.filhos.get(i)).setIrmaos();
      }
   }

   }
    //Getters
    public String getNome(){
        return this.nome;
    }
    public int getIdade(){
        return this.idade;
    }
    public Pessoa getMae(){
        return this.mae;
    }
    public Pessoa getPai(){
        return this.pai;
    }
    //************************************
            
            
    public String nomeIrmaos(){
        String mensagem="Meus irmaos sao ";
        int i;
        for(i=0;i<irmaos.size();i++)
        {
            mensagem +=irmaos.get(i).nome;
            if(i<irmaos.size()-1){
                mensagem+=", ";
            }
        }
        return mensagem;
    
    }
    public int qtdIrmaos(){
        return this.irmaos.size();
    }
    
    public String nomeFilhos(){
        String mensagem="Meus filhos sao ";
        int i;
        for(i=0;i<filhos.size();i++)
        {
            mensagem +=filhos.get(i).nome;
            if (i < filhos.size()-1){
                mensagem+=", ";
            }
        }
        return mensagem;
    
    }
    public int qtdFilhos(){
        return this.filhos.size();
    }
    
}
